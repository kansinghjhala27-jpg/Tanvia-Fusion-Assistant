# Tanvia Fusion — improved voice build

## कैसे इस्तेमाल करें
1. App खोलें और Microphone permission Allow करें.
2. **Start Background Assistant** एक बार दबाएँ.
3. Notification में Tanvia active दिखे तो बोलें: **“Hey Tanvia, YouTube खोलो”**, **“तनविया व्हाट्सएप खोलो”**, **“तनविया कैमरा खोलो”** आदि.
4. Hindi/Hinglish app-name aliases शामिल हैं.

## जरूरी बात
यह build Android SpeechRecognizer पर चलता है. यह अपने आप हर सामान्य बातचीत का अर्थ नहीं निकालता. General-purpose AI answers के लिए app के **AI Brain / API Settings** में वैध API key देनी होगी. बिना AI key के supported phone/app commands ही चलेंगे.

Android की background microphone restrictions और Vivo battery management के कारण background listening को पहली बार user को app से शुरू करना पड़ता है; Android third-party app को बिना अनुमति हमेशा छिपकर microphone पर सुनने की अनुमति नहीं देता.

## AI Brain (Natural Hindi/Hinglish)

इस build में AI Brain जोड़ा गया है। App के **AI Brain Settings** में अपनी OpenAI API key डालने पर Tanvia natural-language commands को action में बदलता है। Default model `gpt-5.6-luna` है; model field में उपलब्ध API model ID बदला जा सकता है।

उदाहरण:
- “Tanvia, कल सुबह 8 बजे का alarm लगा दो।”
- “Tanvia, YouTube खोल दो।”
- “Tanvia, Google पर आज का मौसम खोजो।”
- “Tanvia, 10 मिनट बाद मुझे पानी पीने की याद दिलाना।”
- “Tanvia, WhatsApp खोलकर यह message तैयार करो…”
- सामान्य सवाल पूछने पर AI जवाब भी देता है।

API key केवल इस app की local preferences में रखी जाती है। OpenAI API उपयोग के लिए API account/billing लागू हो सकती है।
