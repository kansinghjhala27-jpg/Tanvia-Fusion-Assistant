package com.tanvia.fusion;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

/** AI command understanding layer. It converts natural Hindi/Hinglish into a small, safe action JSON. */
public final class AIIntentEngine {
    public static final class IntentResult {
        public String action = "ANSWER";
        public String app = "";
        public String query = "";
        public String text = "";
        public String recipient = "";
        public int hour = -1;
        public int minute = -1;
        public int daysFromToday = 0;
        public int durationMinutes = -1;
        public int volumeSteps = 0;
        public boolean ok = false;
    }

    public interface Callback { void onResult(IntentResult result, String error); }
    private static final ExecutorService EXEC = Executors.newCachedThreadPool();

    private AIIntentEngine() {}

    public static boolean configured(Context c) {
        return !c.getSharedPreferences("tanvia", Context.MODE_PRIVATE)
                .getString("openai_key", "").trim().isEmpty();
    }

    public static void interpret(Context context, String userText, Callback cb) {
        SharedPreferences p = context.getSharedPreferences("tanvia", Context.MODE_PRIVATE);
        final String key = p.getString("openai_key", "").trim();
        final String model = p.getString("openai_model", "gpt-5.6-luna").trim();
        if (key.isEmpty()) { cb.onResult(null, "API key not configured"); return; }
        EXEC.submit(() -> {
            try {
                URL url = new URL("https://api.openai.com/v1/responses");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(12000);
                c.setReadTimeout(20000);
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setRequestProperty("Content-Type", "application/json");
                c.setDoOutput(true);

                String instructions =
                    "You are Tanvia Fusion, a Hindi/Hinglish Android phone assistant. " +
                    "Understand the user's natural language and choose exactly one action. " +
                    "Return ONLY one compact JSON object, no markdown and no explanation. " +
                    "Allowed actions: OPEN_APP, SEARCH_WEB, SET_ALARM, SET_REMINDER, OPEN_CALL, OPEN_MESSAGE, " +
                    "VOLUME_UP, VOLUME_DOWN, MUTE, ANSWER, STOP. " +
                    "For OPEN_APP use app: youtube, whatsapp, instagram, spotify, chrome, gmail, maps, chatgpt, camera, settings, calendar. " +
                    "For SEARCH_WEB use query. For OPEN_MESSAGE use text and optional recipient. " +
                    "For SET_ALARM use hour (0-23), minute (0-59), and daysFromToday (0 today, 1 tomorrow; use 0 unless user clearly says tomorrow). " +
                    "For SET_REMINDER use durationMinutes and text. " +
                    "If the user asks a general question, use ANSWER and put the answer in text. " +
                    "Never invent a phone number. If a required detail is missing, choose ANSWER and ask a short clarification. " +
                    "JSON keys: action, app, query, text, recipient, hour, minute, daysFromToday, durationMinutes, volumeSteps.";

                String body = "{\"model\":\"" + esc(model) + "\",\"instructions\":\"" + esc(instructions) +
                        "\",\"input\":\"" + esc(userText) + "\"}";
                try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                int code = c.getResponseCode();
                InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                String raw = readAll(is);
                if (code < 200 || code >= 300) { cb.onResult(null, "API error " + code + ": " + raw); return; }
                String out = extractOutputText(raw);
                IntentResult r = parse(out);
                if (!r.ok) { cb.onResult(null, "AI returned invalid action"); return; }
                cb.onResult(r, null);
            } catch (Exception e) {
                cb.onResult(null, e.getMessage() == null ? "AI connection failed" : e.getMessage());
            }
        });
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }
    private static String extractOutputText(String j) {
        int p = j.indexOf("\"output_text\"");
        if (p < 0) return "";
        int c = j.indexOf(':', p); int q = j.indexOf('"', c + 1);
        if (q < 0) return "";
        StringBuilder s = new StringBuilder(); boolean esc = false;
        for (int i = q + 1; i < j.length(); i++) {
            char ch = j.charAt(i);
            if (esc) { if (ch == 'n') s.append('\n'); else if (ch == 'r') s.append('\r'); else s.append(ch); esc = false; }
            else if (ch == '\\') esc = true;
            else if (ch == '"') break;
            else s.append(ch);
        }
        return s.toString();
    }
    private static String str(String j, String key) {
        String needle = "\"" + key + "\""; int p = j.indexOf(needle); if (p < 0) return "";
        int c = j.indexOf(':', p + needle.length()); if (c < 0) return "";
        int q = j.indexOf('"', c + 1); if (q < 0) return "";
        StringBuilder s = new StringBuilder(); boolean esc = false;
        for (int i=q+1;i<j.length();i++){char ch=j.charAt(i);if(esc){if(ch=='n')s.append('\n');else if(ch=='r')s.append('\r');else s.append(ch);esc=false;}else if(ch=='\\')esc=true;else if(ch=='"')break;else s.append(ch);}return s.toString();
    }
    private static int num(String j, String key, int def) {
        String needle = "\"" + key + "\""; int p=j.indexOf(needle); if(p<0)return def; int c=j.indexOf(':',p+needle.length()); if(c<0)return def;
        int i=c+1; while(i<j.length() && Character.isWhitespace(j.charAt(i)))i++; int e=i; while(e<j.length() && (j.charAt(e)=='-'||Character.isDigit(j.charAt(e))))e++;
        try{return Integer.parseInt(j.substring(i,e));}catch(Exception x){return def;}
    }
    private static IntentResult parse(String out) {
        int a=out.indexOf('{'), b=out.lastIndexOf('}'); if(a<0||b<=a)return new IntentResult();
        String j=out.substring(a,b+1); IntentResult r=new IntentResult();
        r.action=str(j,"action").toUpperCase(); r.app=str(j,"app"); r.query=str(j,"query"); r.text=str(j,"text"); r.recipient=str(j,"recipient");
        r.hour=num(j,"hour",-1); r.minute=num(j,"minute",-1); r.daysFromToday=num(j,"daysFromToday",0); r.durationMinutes=num(j,"durationMinutes",-1); r.volumeSteps=num(j,"volumeSteps",1);
        r.ok = !r.action.isEmpty(); return r;
    }
}
