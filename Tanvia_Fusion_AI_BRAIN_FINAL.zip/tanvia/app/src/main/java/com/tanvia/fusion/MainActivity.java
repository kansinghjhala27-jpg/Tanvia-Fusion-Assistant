package com.tanvia.fusion;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    EditText command;
    TextView heard, reply, memoryText;
    TextToSpeech tts;
    SpeechRecognizer sr;
    SharedPreferences prefs;
    Handler handler = new Handler(Looper.getMainLooper());
    ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        command = findViewById(R.id.commandText);
        heard = findViewById(R.id.heardText);
        reply = findViewById(R.id.replyText);
        memoryText = findViewById(R.id.memoryText);
        prefs = getSharedPreferences("tanvia", MODE_PRIVATE);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });

        findViewById(R.id.runButton).setOnClickListener(v -> runCommand(command.getText().toString()));
        findViewById(R.id.micButton).setOnClickListener(v -> listen());
        findViewById(R.id.micButton).setOnLongClickListener(v -> { startVoiceService(); return true; });
        findViewById(R.id.permissionsButton).setOnClickListener(v -> openPermissions());
        findViewById(R.id.aiButton).setOnClickListener(v -> aiSettings());
        findViewById(R.id.backgroundButton).setOnClickListener(v -> startVoiceService());

        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        updateMemoryCount();
    }

    void startVoiceService() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
            respond("पहले microphone permission दें, फिर Background Assistant दबाएँ।");
            return;
        }
        try {
            Intent i = new Intent(this, TanviaVoiceService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            respond("Background assistant चालू है। अब app बार-बार खोलने की जरूरत नहीं—'Hey Tanvia' बोलिए।");
        } catch (Exception e) { respond("Voice service शुरू नहीं हो सकी। Microphone permission जाँचें।"); }
    }

    void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { respond("इस फोन पर speech recognition उपलब्ध नहीं है।"); return; }
        if (sr != null) sr.destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
            public void onError(int e) { respond("आवाज़ समझ नहीं आई। फिर से बोलिए।"); }
            public void onResults(Bundle b) {
                ArrayList<String> x = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (x != null && !x.isEmpty()) {
                    String chosen = x.get(0);
                    // Prefer a candidate containing a known app/action word.
                    String[] keys = {"youtube","यूट्यूब","whatsapp","व्हाट्सएप","instagram","इंस्टाग्राम","spotify","स्पॉटिफाई","chrome","क्रोम","camera","कैमरा","settings","सेटिंग","maps","मैप","google","गूगल","call","कॉल","message","मैसेज"};
                    for (String r : x) { String nr=r.toLowerCase(Locale.ROOT); for (String k:keys) if(nr.contains(k)){chosen=r; break;} }
                    heard.setText("“" + chosen + "”"); runCommand(chosen);
                }
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        sr.startListening(i);
    }

    void runCommand(String q) {
        if (q == null || q.trim().isEmpty()) return;
        if (AIIntentEngine.configured(this)) {
            respond("समझ रहा हूँ…");
            AIIntentEngine.interpret(this, q.trim(), (r, err) -> handler.post(() -> {
                if (r != null) executeAIIntent(r);
                else runLocalCommand(q);
            }));
        } else {
            runLocalCommand(q);
        }
    }

    void runLocalCommand(String q) {
        if (q == null || q.trim().isEmpty()) return;
        q = q.trim(); heard.setText("“" + q + "”");
        String l = q.toLowerCase(Locale.ROOT).trim();
        try {
            if (l.contains("stop") || l.contains("बंद हो जाओ")) respond("ठीक है।");
            else if (l.contains("time") || l.contains("समय")) respond("अभी समय " + new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()) + " है।");
            else if (l.contains("date") || l.contains("तारीख") || l.contains("आज कौन सा दिन")) respond("आज " + new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("hi","IN")).format(new Date()) + " है।");
            else if (l.contains("battery") || l.contains("बैटरी")) { BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); respond("Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " प्रतिशत है।"); }
            else if (l.contains("ram") || l.contains("system") || l.contains("सिस्टम")) { ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); respond("Available system memory " + (mi.availMem/1024/1024) + " MB है।"); }
            else if ((l.contains("whatsapp") || l.contains("व्हाट्सएप") || l.contains("व्हाट्सऐप"))) openPackage("com.whatsapp", "WhatsApp");
            else if ((l.contains("youtube") || l.contains("यूट्यूब"))) openPackage("com.google.android.youtube", "YouTube");
            else if ((l.contains("instagram") || l.contains("इंस्टाग्राम"))) openPackage("com.instagram.android", "Instagram");
            else if ((l.contains("spotify") || l.contains("स्पॉटिफाई"))) openPackage("com.spotify.music", "Spotify");
            else if ((l.contains("chrome") || l.contains("क्रोम"))) openPackage("com.android.chrome", "Chrome");
            else if (l.contains("gmail") || l.contains("mail") || l.contains("जीमेल")) openUrl("https://mail.google.com/", "Gmail");
            else if (l.contains("maps") || l.contains("नक्शा")) openUrl("https://maps.google.com/", "Maps");
            else if (l.contains("chatgpt")) openUrl("https://chatgpt.com/", "ChatGPT");
            else if (l.contains("music") || l.contains("गाना") || l.contains("म्यूजिक")) openUrl("https://music.youtube.com/", "Music");
            else if (l.contains("google") || l.contains("search") || l.contains("सर्च") || l.contains("इंटरनेट")) { String search=q.replaceAll("(?i)google|search|सर्च|internet|इंटरनेट", "").trim(); openUrl("https://www.google.com/search?q="+Uri.encode(search.isEmpty()?q:search), "Google search"); }
            else if (l.contains("camera") || l.contains("कैमरा")) { respond("Camera खोल रहा हूँ।"); startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
            else if (l.contains("call") || l.contains("कॉल")) { respond("Phone dialer खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_DIAL)); }
            else if (l.contains("sms") || l.contains("message") || l.contains("मैसेज")) { respond("Messaging app खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)); }
            else if (l.contains("calendar") || l.contains("कैलेंडर")) { respond("Calendar खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)); }
            else if (l.contains("alarm") || l.contains("अलार्म")) { respond("Alarm app खोल रहा हूँ।"); startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); }
            else if (l.contains("settings") || l.contains("सेटिंग")) startActivity(new Intent(Settings.ACTION_SETTINGS));
            else if (l.contains("wifi") || l.contains("वाईफाई")) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); respond("Wi-Fi settings खोल रहा हूँ।"); }
            else if (l.contains("bluetooth")) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); respond("Bluetooth settings खोल रहा हूँ।"); }
            else if (l.contains("volume up") || l.contains("आवाज बढ़ाओ") || l.contains("आवाज़ बढ़ाओ")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); respond("Volume बढ़ा दिया।"); }
            else if (l.contains("volume down") || l.contains("आवाज कम") || l.contains("आवाज़ कम")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); respond("Volume कम कर दिया।"); }
            else if (l.contains("mute") || l.contains("म्यूट")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); respond("Mute कर दिया।"); }
            else if (l.startsWith("remember") || l.startsWith("याद रखना") || l.startsWith("याद रखो")) remember(q);
            else if (l.contains("memory") || l.contains("मेरी memory") || l.contains("क्या याद है")) showMemory();
            else if (l.contains("remind me") || l.contains("reminder") || l.contains("रिमाइंड") || l.contains("याद दिलाना")) addReminder(q);
            else if (l.contains("accessibility")) openPermissions();
            else respond("AI Brain उपलब्ध नहीं है। OpenAI API key सेट करें, फिर यही बात दोबारा बोलें।");
        } catch(Exception e) { respond("यह action इस फोन पर उपलब्ध नहीं है या permission चाहिए।"); }
    }

    void openPackage(String pkg,String name){ Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){startActivity(i);respond(name+" खोल रहा हूँ।");}else openUrl("https://www.google.com/search?q="+Uri.encode(name),name); }
    void openUrl(String url,String name){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));respond(name+" खोल रहा हूँ।");}
    void remember(String q){String value=q.replaceFirst("(?i)^(remember|याद रखना|याद रखो)\\s*","").trim();if(value.isEmpty()){respond("क्या याद रखना है?");return;}prefs.edit().putString("mem_"+System.currentTimeMillis(),value).apply();updateMemoryCount();respond("ठीक है, मैंने याद रख लिया।");}
    void showMemory(){Map<String,?> all=prefs.getAll();ArrayList<String> list=new ArrayList<>();for(Map.Entry<String,?> e:all.entrySet())if(e.getKey().startsWith("mem_"))list.add(String.valueOf(e.getValue()));if(list.isEmpty()){respond("मेरी memory अभी खाली है।");return;}StringBuilder sb=new StringBuilder("मेरी saved memory: ");for(int i=Math.max(0,list.size()-5);i<list.size();i++)sb.append(list.get(i)).append(". ");respond(sb.toString());}
    void updateMemoryCount(){int n=0;for(String k:prefs.getAll().keySet())if(k.startsWith("mem_"))n++;memoryText.setText("Memory: "+n);}
    void addReminder(String q){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+)\\s*(minute|minutes|min|मिनट)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(q);if(!m.find()){respond("उदाहरण: 10 मिनट बाद मुझे call करने की याद दिलाना।");return;}int minutes=Integer.parseInt(m.group(1));String task=q.substring(m.end()).trim();if(task.startsWith("बाद"))task=task.substring(2).trim();final String finalTask=task.isEmpty()?"Reminder":task;handler.postDelayed(()->respond("Reminder: "+finalTask),minutes*60_000L);respond(minutes+" मिनट बाद reminder लगा दिया।");}

    void executeAIIntent(AIIntentEngine.IntentResult r) {
        try {
            String a = r.action == null ? "ANSWER" : r.action.toUpperCase(Locale.ROOT);
            if ("OPEN_APP".equals(a)) {
                String app = r.app == null ? "" : r.app.toLowerCase(Locale.ROOT);
                if (app.equals("youtube")) openPackage("com.google.android.youtube","YouTube");
                else if (app.equals("whatsapp")) openPackage("com.whatsapp","WhatsApp");
                else if (app.equals("instagram")) openPackage("com.instagram.android","Instagram");
                else if (app.equals("spotify")) openPackage("com.spotify.music","Spotify");
                else if (app.equals("chrome")) openPackage("com.android.chrome","Chrome");
                else if (app.equals("gmail")) openUrl("https://mail.google.com/","Gmail");
                else if (app.equals("maps")) openUrl("https://maps.google.com/","Maps");
                else if (app.equals("chatgpt")) openUrl("https://chatgpt.com/","ChatGPT");
                else if (app.equals("camera")) { respond("Camera खोल रहा हूँ।"); startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
                else if (app.equals("settings")) { startActivity(new Intent(Settings.ACTION_SETTINGS)); respond("Settings खोल रहा हूँ।"); }
                else if (app.equals("calendar")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)); respond("Calendar खोल रहा हूँ।"); }
                else runLocalCommand("" + app);
            } else if ("SEARCH_WEB".equals(a)) {
                String q = r.query == null || r.query.trim().isEmpty() ? r.text : r.query;
                openUrl("https://www.google.com/search?q=" + Uri.encode(q == null ? "" : q), "Google search");
            } else if ("SET_ALARM".equals(a)) {
                if (r.hour < 0 || r.minute < 0) { respond("Alarm का समय बताइए, जैसे कल सुबह 8 बजे।"); return; }
                Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM);
                i.putExtra(android.provider.AlarmClock.EXTRA_HOUR, r.hour);
                i.putExtra(android.provider.AlarmClock.EXTRA_MINUTES, r.minute);
                if (r.text != null && !r.text.isEmpty()) i.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, r.text);
                if (r.daysFromToday == 1) {
                    ArrayList<Integer> days = new ArrayList<>();
                    Calendar cal = Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR, 1); days.add(cal.get(Calendar.DAY_OF_WEEK));
                    i.putExtra(android.provider.AlarmClock.EXTRA_DAYS, days);
                }
                startActivity(i); respond("Alarm " + String.format(Locale.getDefault(), "%02d:%02d", r.hour, r.minute) + " के लिए सेट करने का विकल्प खोल रहा हूँ।");
            } else if ("SET_REMINDER".equals(a)) {
                int mins = r.durationMinutes;
                if (mins <= 0) { respond("कितने समय बाद reminder चाहिए, बताइए।"); return; }
                scheduleReminder(r.text == null || r.text.isEmpty() ? "Reminder" : r.text, mins);
                respond(mins + " मिनट बाद reminder लगा दिया।");
            } else if ("OPEN_MESSAGE".equals(a)) {
                String text = r.text == null ? "" : r.text;
                String number = r.recipient == null ? "" : r.recipient.replaceAll("[^0-9+]", "");
                String url = number.length() >= 8 ? "https://wa.me/" + number.replace("+", "") + "?text=" + Uri.encode(text) : "https://wa.me/?text=" + Uri.encode(text);
                openUrl(url, "WhatsApp");
            } else if ("OPEN_CALL".equals(a)) {
                String number = r.recipient == null ? "" : r.recipient.replaceAll("[^0-9+]", "");
                Intent i = new Intent(Intent.ACTION_DIAL); if (!number.isEmpty()) i.setData(Uri.parse("tel:" + number)); startActivity(i); respond("Phone खोल रहा हूँ।");
            } else if ("VOLUME_UP".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); respond("Volume बढ़ा दिया।");
            } else if ("VOLUME_DOWN".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); respond("Volume कम कर दिया।");
            } else if ("MUTE".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); respond("Mute कर दिया।");
            } else if ("STOP".equals(a)) { respond("ठीक है।"); }
            else { respond(r.text == null || r.text.isEmpty() ? "मैं आपकी बात समझ नहीं पाया।" : r.text); }
        } catch (Exception e) { runLocalCommand(r.text == null ? "" : r.text); }
    }

    void scheduleReminder(String text, int minutes) {
        long when = System.currentTimeMillis() + minutes * 60_000L;
        Intent i = new Intent(this, TanviaReminderReceiver.class).putExtra("text", text);
        PendingIntent pi = PendingIntent.getBroadcast(this, (int)(when/1000), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    void aiSettings(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,24,24,24);EditText key=new EditText(this);key.setHint("OpenAI API key");key.setInputType(0x81);key.setText(prefs.getString("openai_key",""));box.addView(key);EditText model=new EditText(this);model.setHint("Model");model.setText(prefs.getString("openai_model","gpt-5.6-luna"));box.addView(model);new AlertDialog.Builder(this).setTitle("AI Brain Settings").setView(box).setMessage("API key केवल इस app की local preferences में रखी जाएगी।").setPositiveButton("Save",(d,w)->{prefs.edit().putString("openai_key",key.getText().toString().trim()).putString("openai_model",model.getText().toString().trim()).apply();respond("AI settings save हो गईं।");}).setNegativeButton("Cancel",null).show();}
    void openPermissions(){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}
    void respond(String s){reply.setText(s);if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"tanvia");}
    @Override protected void onDestroy(){if(sr!=null)sr.destroy();if(tts!=null){tts.stop();tts.shutdown();}executor.shutdownNow();super.onDestroy();}
}
