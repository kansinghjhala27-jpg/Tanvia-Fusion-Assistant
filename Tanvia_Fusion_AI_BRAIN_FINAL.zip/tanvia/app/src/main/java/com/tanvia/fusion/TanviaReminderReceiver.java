package com.tanvia.fusion;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import java.util.*;

public class TanviaReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String text=intent.getStringExtra("text"); if(text==null||text.isEmpty())text="Reminder";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("tanvia_reminders","Tanvia Reminders",NotificationManager.IMPORTANCE_HIGH);nm.createNotificationChannel(ch);}
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"tanvia_reminders"):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Tanvia Reminder").setContentText(text).setAutoCancel(true);
        nm.notify((int)(System.currentTimeMillis()/1000),b.build());
        final TextToSpeech[] tts={null};
        tts[0]=new TextToSpeech(context,status->{if(status==TextToSpeech.SUCCESS){tts[0].setLanguage(new Locale("hi","IN"));tts[0].speak("Reminder: "+text,TextToSpeech.QUEUE_FLUSH,null,"tanvia-reminder");}});
    }
}
