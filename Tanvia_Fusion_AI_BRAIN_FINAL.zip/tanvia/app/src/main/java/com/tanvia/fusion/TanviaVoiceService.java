package com.tanvia.fusion;

import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import java.util.*;

/**
 * Foreground voice assistant. It listens in short recognition sessions and only
 * executes commands after the wake word "Tanvia" / "Hey Tanvia" is detected.
 * Android still shows the required microphone foreground-service notification.
 */
public class TanviaVoiceService extends Service {
    private static final int NOTIFICATION_ID = 777;
    private static final String CHANNEL = "tanvia_voice";
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean waitingForCommand = false;
    private boolean listening = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Tanvia Fusion active")
                .setContentText("Voice assistant is listening for the wake word: Tanvia")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, 128);
        else startForeground(NOTIFICATION_ID, n);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        running = true;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(CHANNEL, "Tanvia Voice", NotificationManager.IMPORTANCE_LOW);
            nc.setDescription("Tanvia background voice assistant");
            getSystemService(NotificationManager.class).createNotificationChannel(nc);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) running = true;
        main.postDelayed(this::listenAgain, 250);
        return START_STICKY;
    }

    private void listenAgain() {
        if (!running || listening) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फोन पर voice recognition उपलब्ध नहीं है।");
            return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { listening = true; }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { listening = false; }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int a, Bundle b) {}
                public void onError(int e) { listening = false; main.postDelayed(TanviaVoiceService.this::listenAgain, 500); }
                public void onResults(Bundle b) {
                    listening = false;
                    ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (results != null && !results.isEmpty()) {
                        String chosen = results.get(0);
                        // Prefer a recognition candidate that contains the wake word.
                        for (String r : results) {
                            String nr = normalize(r);
                            if (findWakeWord(nr) != null) { chosen = r; break; }
                        }
                        handleSpeech(chosen);
                    }
                    main.postDelayed(TanviaVoiceService.this::listenAgain, 350);
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            recognizer.startListening(i);
        } catch (Exception e) {
            listening = false;
            main.postDelayed(this::listenAgain, 1200);
        }
    }

    private void handleSpeech(String text) {
        if (text == null) return;
        String original = text.trim();
        String l = normalize(original);
        String wake = findWakeWord(l);

        if (waitingForCommand) {
            waitingForCommand = false;
            executeCommand(original);
            return;
        }

        if (wake != null) {
            String command = l.substring(wake.length()).trim();
            if (command.startsWith(",") || command.startsWith(":")) command = command.substring(1).trim();
            if (command.isEmpty()) {
                waitingForCommand = true;
                speak("जी, बोलिए।");
            } else {
                executeCommand(command);
            }
        }
    }

    private String findWakeWord(String l) {
        String[] wakes = {"hey tanvia", "hey tanvi", "hey tanvya", "tanvia", "tanvi", "tanvya", "हे तनविया", "हे तन्विया", "हे तनव्या", "तनविया", "तन्विया", "तनव्या", "तनवीया"};
        for (String w : wakes) {
            if (l.startsWith(w)) return w;
        }
        return null;
    }

    private String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " ");
    }

    private boolean has(String text, String... words) {
        for (String w : words) if (text.contains(w)) return true;
        return false;
    }

    private void executeCommand(String q) {
        if (q == null || q.trim().isEmpty()) return;
        if (AIIntentEngine.configured(this)) {
            speak("समझ रहा हूँ…");
            AIIntentEngine.interpret(this, q.trim(), (r, err) -> main.post(() -> {
                if (r != null) executeAIIntent(r);
                else executeLocalCommand(q);
            }));
        } else {
            executeLocalCommand(q);
        }
    }

    private void executeLocalCommand(String q) {
        String l = normalize(q);
        try {
            if (l.contains("stop listening") || l.contains("voice बंद") || l.contains("बंद हो जाओ") || l.equals("stop") || l.contains("सुनना बंद")) {
                speak("ठीक है, voice assistant बंद कर रहा हूँ।");
                stopSelf();
            } else if (has(l, "youtube", "यूट्यूब", "यूट्यूब")) openPackage("com.google.android.youtube", "YouTube");
            else if (has(l, "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप")) openPackage("com.whatsapp", "WhatsApp");
            else if (has(l, "instagram", "इंस्टाग्राम", "इन्स्टाग्राम")) openPackage("com.instagram.android", "Instagram");
            else if (has(l, "spotify", "स्पॉटिफाई", "स्पोटिफाई")) openPackage("com.spotify.music", "Spotify");
            else if (has(l, "chrome", "क्रोम")) openPackage("com.android.chrome", "Chrome");
            else if (has(l, "gmail", "email", "मेल", "जीमेल")) openUrl("https://mail.google.com/", "Gmail");
            else if (has(l, "google maps", "maps", "नक्शा", "मैप", "गूगल मैप")) openUrl("https://maps.google.com/", "Maps");
            else if (has(l, "chatgpt", "चैटजीपीटी", "चैट जीपीटी")) openUrl("https://chatgpt.com/", "ChatGPT");
            else if (has(l, "camera", "कैमरा")) { speak("Camera खोल रहा हूँ।"); startActivity(new Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            else if (has(l, "settings", "setting", "सेटिंग", "सेटिंग्स")) { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Settings खोल रहा हूँ।"); }
            else if (has(l, "wifi", "wi-fi", "वाईफाई", "वाई फाई")) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Wi-Fi settings खोल रहा हूँ।"); }
            else if (has(l, "bluetooth", "ब्लूटूथ")) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Bluetooth settings खोल रहा हूँ।"); }
            else if (has(l, "calendar", "कैलेंडर")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Calendar खोल रहा हूँ।"); }
            else if (has(l, "alarm", "अलार्म")) { startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Alarm खोल रहा हूँ।"); }
            else if (has(l, "message", "messages", "sms", "मैसेज", "मैसेजेस", "संदेश")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Messages खोल रहा हूँ।"); }
            else if (has(l, "call", "phone", "कॉल", "फोन")) { startActivity(new Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Phone खोल रहा हूँ।"); }
            else if (has(l, "volume up", "आवाज बढ़ाओ", "आवाज़ बढ़ाओ", "आवाज बढ़ा", "आवाज़ बढ़ा")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); speak("Volume बढ़ा दिया।"); }
            else if (has(l, "volume down", "आवाज कम", "आवाज़ कम", "आवाज घटा", "आवाज़ घटा")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); speak("Volume कम कर दिया।"); }
            else if (has(l, "mute", "म्यूट", "आवाज बंद", "आवाज़ बंद")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); speak("Mute कर दिया।"); }
            else if (has(l, "google", "search", "सर्च", "इंटरनेट", "खोजो", "ढूंढो", "ढूँढो")) {
                String search = l.replace("google", "").replace("search", "").replace("सर्च", "").replace("इंटरनेट", "").replace("खोजो", "").replace("ढूंढो", "").replace("ढूँढो", "").trim();
                openUrl("https://www.google.com/search?q=" + Uri.encode(search.isEmpty() ? original : search), "Google search");
            } else {
                speak("मैंने सुना: " + original + ". इस command के लिए AI Brain चाहिए या command का app-name बोलें, जैसे ‘Tanvia YouTube खोलो’।");
            }
        } catch (Exception e) {
            speak("यह action इस फोन पर उपलब्ध नहीं है या permission चाहिए।");
        }
    }

    private void executeAIIntent(AIIntentEngine.IntentResult r) {
        try {
            String a = r.action == null ? "ANSWER" : r.action.toUpperCase(Locale.ROOT);
            if ("OPEN_APP".equals(a)) {
                String app = r.app == null ? "" : r.app.toLowerCase(Locale.ROOT);
                if (app.equals("youtube")) openPackage("com.google.android.youtube","YouTube");
                else if (app.equals("whatsapp")) openPackage("com.whatsapp","WhatsApp");
                else if (app.equals("instagram")) openPackage("com.instagram.android","Instagram");
                else if (app.equals("spotify")) openPackage("com.spotify.music","Spotify");
                else if (app.equals("chrome")) openPackage("com.android.chrome","Chrome");
                else if (app.equals("gmail")) openUrl("https://mail.google.com/","Gmail");
                else if (app.equals("maps")) openUrl("https://maps.google.com/","Maps");
                else if (app.equals("chatgpt")) openUrl("https://chatgpt.com/","ChatGPT");
                else if (app.equals("camera")) { startActivity(new Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Camera खोल रहा हूँ।"); }
                else if (app.equals("settings")) { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Settings खोल रहा हूँ।"); }
                else if (app.equals("calendar")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Calendar खोल रहा हूँ।"); }
                else executeLocalCommand(app);
            } else if ("SEARCH_WEB".equals(a)) {
                String q = r.query == null || r.query.trim().isEmpty() ? r.text : r.query; openUrl("https://www.google.com/search?q=" + Uri.encode(q == null ? "" : q), "Google search");
            } else if ("SET_ALARM".equals(a)) {
                if (r.hour < 0 || r.minute < 0) { speak("Alarm का समय बताइए।"); return; }
                Intent i = new Intent(android.provider.AlarmClock.ACTION_SET_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra(android.provider.AlarmClock.EXTRA_HOUR, r.hour); i.putExtra(android.provider.AlarmClock.EXTRA_MINUTES, r.minute);
                if (r.text != null && !r.text.isEmpty()) i.putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, r.text);
                if (r.daysFromToday == 1) { ArrayList<Integer> days=new ArrayList<>(); Calendar cal=Calendar.getInstance(); cal.add(Calendar.DAY_OF_YEAR,1); days.add(cal.get(Calendar.DAY_OF_WEEK)); i.putExtra(android.provider.AlarmClock.EXTRA_DAYS,days); }
                startActivity(i); speak("Alarm " + String.format(Locale.getDefault(), "%02d:%02d", r.hour, r.minute) + " के लिए खोल रहा हूँ।");
            } else if ("SET_REMINDER".equals(a)) {
                if (r.durationMinutes <= 0) { speak("कितने समय बाद reminder चाहिए?"); return; }
                scheduleReminder(r.text == null || r.text.isEmpty() ? "Reminder" : r.text, r.durationMinutes); speak(r.durationMinutes + " मिनट बाद reminder लगा दिया।");
            } else if ("OPEN_MESSAGE".equals(a)) {
                String text=r.text==null?"":r.text; String number=r.recipient==null?"":r.recipient.replaceAll("[^0-9+]","");
                String url=number.length()>=8?"https://wa.me/"+number.replace("+","")+"?text="+Uri.encode(text):"https://wa.me/?text="+Uri.encode(text); openUrl(url,"WhatsApp");
            } else if ("OPEN_CALL".equals(a)) {
                String number=r.recipient==null?"":r.recipient.replaceAll("[^0-9+]",""); Intent i=new Intent(Intent.ACTION_DIAL); if(!number.isEmpty()) i.setData(Uri.parse("tel:"+number)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); speak("Phone खोल रहा हूँ।");
            } else if ("VOLUME_UP".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI); speak("Volume बढ़ा दिया।");
            } else if ("VOLUME_DOWN".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI); speak("Volume कम कर दिया।");
            } else if ("MUTE".equals(a)) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI); speak("Mute कर दिया।");
            } else if ("STOP".equals(a)) { speak("ठीक है।"); stopSelf(); }
            else speak(r.text == null || r.text.isEmpty() ? "मैं आपकी बात समझ नहीं पाया।" : r.text);
        } catch(Exception e) { executeLocalCommand(r.text == null ? "" : r.text); }
    }

    private void scheduleReminder(String text, int minutes) {
        long when=System.currentTimeMillis()+minutes*60_000L; Intent i=new Intent(this,TanviaReminderReceiver.class).putExtra("text",text);
        PendingIntent pi=PendingIntent.getBroadcast(this,(int)(when/1000),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }

    private void openPackage(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            speak(name + " खोल रहा हूँ।");
        } else {
            openUrl("https://www.google.com/search?q=" + Uri.encode(name), name);
        }
    }

    private void openUrl(String url, String name) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        speak(name + " खोल रहा हूँ।");
    }

    private void speak(String s) {
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "tanvia");
    }

    @Override public void onDestroy() {
        running = false;
        listening = false;
        if (recognizer != null) { try { recognizer.cancel(); } catch (Exception ignored) {} recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
