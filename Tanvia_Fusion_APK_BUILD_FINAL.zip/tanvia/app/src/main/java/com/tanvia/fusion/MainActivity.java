package com.tanvia.fusion;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    EditText command;
    TextView heard, reply, memoryText;
    TextToSpeech tts;
    SpeechRecognizer sr;
    SharedPreferences prefs;
    Handler handler = new Handler(Looper.getMainLooper());
    ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        command = findViewById(R.id.commandText);
        heard = findViewById(R.id.heardText);
        reply = findViewById(R.id.replyText);
        memoryText = findViewById(R.id.memoryText);
        prefs = getSharedPreferences("tanvia", MODE_PRIVATE);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });

        findViewById(R.id.runButton).setOnClickListener(v -> runCommand(command.getText().toString()));
        findViewById(R.id.micButton).setOnClickListener(v -> listen());
        findViewById(R.id.micButton).setOnLongClickListener(v -> { startVoiceService(); return true; });
        findViewById(R.id.permissionsButton).setOnClickListener(v -> openPermissions());
        findViewById(R.id.aiButton).setOnClickListener(v -> aiSettings());
        findViewById(R.id.backgroundButton).setOnClickListener(v -> startVoiceService());

        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        updateMemoryCount();
    }

    void startVoiceService() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
            respond("पहले microphone permission दें, फिर Background Assistant दबाएँ।");
            return;
        }
        try {
            Intent i = new Intent(this, TanviaVoiceService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            respond("Background assistant चालू है। अब app बार-बार खोलने की जरूरत नहीं—'Hey Tanvia' बोलिए।");
        } catch (Exception e) { respond("Voice service शुरू नहीं हो सकी। Microphone permission जाँचें।"); }
    }

    void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { respond("इस फोन पर speech recognition उपलब्ध नहीं है।"); return; }
        if (sr != null) sr.destroy();
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {}
            public void onEvent(int a, Bundle b) {}
            public void onError(int e) { respond("आवाज़ समझ नहीं आई। फिर से बोलिए।"); }
            public void onResults(Bundle b) {
                ArrayList<String> x = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (x != null && !x.isEmpty()) { heard.setText("“" + x.get(0) + "”"); runCommand(x.get(0)); }
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        sr.startListening(i);
    }

    void runCommand(String q) {
        if (q == null || q.trim().isEmpty()) return;
        q = q.trim(); heard.setText("“" + q + "”");
        String l = q.toLowerCase(Locale.ROOT);
        try {
            if (l.contains("stop") || l.contains("बंद हो जाओ")) respond("ठीक है।");
            else if (l.contains("time") || l.contains("समय")) respond("अभी समय " + new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()) + " है।");
            else if (l.contains("date") || l.contains("तारीख") || l.contains("आज कौन सा दिन")) respond("आज " + new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("hi","IN")).format(new Date()) + " है।");
            else if (l.contains("battery") || l.contains("बैटरी")) { BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); respond("Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " प्रतिशत है।"); }
            else if (l.contains("ram") || l.contains("system") || l.contains("सिस्टम")) { ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE); ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); respond("Available system memory " + (mi.availMem/1024/1024) + " MB है।"); }
            else if (l.contains("whatsapp")) openPackage("com.whatsapp", "WhatsApp");
            else if (l.contains("youtube")) openPackage("com.google.android.youtube", "YouTube");
            else if (l.contains("instagram")) openPackage("com.instagram.android", "Instagram");
            else if (l.contains("spotify")) openPackage("com.spotify.music", "Spotify");
            else if (l.contains("chrome")) openPackage("com.android.chrome", "Chrome");
            else if (l.contains("gmail") || l.contains("mail")) openUrl("https://mail.google.com/", "Gmail");
            else if (l.contains("maps") || l.contains("नक्शा")) openUrl("https://maps.google.com/", "Maps");
            else if (l.contains("chatgpt")) openUrl("https://chatgpt.com/", "ChatGPT");
            else if (l.contains("music") || l.contains("गाना") || l.contains("म्यूजिक")) openUrl("https://music.youtube.com/", "Music");
            else if (l.contains("google") || l.contains("search") || l.contains("सर्च") || l.contains("इंटरनेट")) { String search=q.replaceAll("(?i)google|search|सर्च|internet|इंटरनेट", "").trim(); openUrl("https://www.google.com/search?q="+Uri.encode(search.isEmpty()?q:search), "Google search"); }
            else if (l.contains("camera") || l.contains("कैमरा")) { respond("Camera खोल रहा हूँ।"); startActivity(new Intent("android.media.action.IMAGE_CAPTURE")); }
            else if (l.contains("call") || l.contains("कॉल")) { respond("Phone dialer खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_DIAL)); }
            else if (l.contains("sms") || l.contains("message") || l.contains("मैसेज")) { respond("Messaging app खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)); }
            else if (l.contains("calendar") || l.contains("कैलेंडर")) { respond("Calendar खोल रहा हूँ।"); startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)); }
            else if (l.contains("alarm") || l.contains("अलार्म")) { respond("Alarm app खोल रहा हूँ।"); startActivity(new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)); }
            else if (l.contains("settings") || l.contains("सेटिंग")) startActivity(new Intent(Settings.ACTION_SETTINGS));
            else if (l.contains("wifi") || l.contains("वाईफाई")) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); respond("Wi-Fi settings खोल रहा हूँ।"); }
            else if (l.contains("bluetooth")) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); respond("Bluetooth settings खोल रहा हूँ।"); }
            else if (l.contains("volume up") || l.contains("आवाज बढ़ाओ") || l.contains("आवाज़ बढ़ाओ")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); respond("Volume बढ़ा दिया।"); }
            else if (l.contains("volume down") || l.contains("आवाज कम") || l.contains("आवाज़ कम")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); respond("Volume कम कर दिया।"); }
            else if (l.contains("mute") || l.contains("म्यूट")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); respond("Mute कर दिया।"); }
            else if (l.startsWith("remember") || l.startsWith("याद रखना") || l.startsWith("याद रखो")) remember(q);
            else if (l.contains("memory") || l.contains("मेरी memory") || l.contains("क्या याद है")) showMemory();
            else if (l.contains("remind me") || l.contains("reminder") || l.contains("रिमाइंड") || l.contains("याद दिलाना")) addReminder(q);
            else if (l.contains("accessibility")) openPermissions();
            else askAI(q);
        } catch(Exception e) { respond("यह action इस फोन पर उपलब्ध नहीं है या permission चाहिए।"); }
    }

    void openPackage(String pkg,String name){ Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){startActivity(i);respond(name+" खोल रहा हूँ।");}else openUrl("https://www.google.com/search?q="+Uri.encode(name),name); }
    void openUrl(String url,String name){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));respond(name+" खोल रहा हूँ।");}
    void remember(String q){String value=q.replaceFirst("(?i)^(remember|याद रखना|याद रखो)\\s*","").trim();if(value.isEmpty()){respond("क्या याद रखना है?");return;}prefs.edit().putString("mem_"+System.currentTimeMillis(),value).apply();updateMemoryCount();respond("ठीक है, मैंने याद रख लिया।");}
    void showMemory(){Map<String,?> all=prefs.getAll();ArrayList<String> list=new ArrayList<>();for(Map.Entry<String,?> e:all.entrySet())if(e.getKey().startsWith("mem_"))list.add(String.valueOf(e.getValue()));if(list.isEmpty()){respond("मेरी memory अभी खाली है।");return;}StringBuilder sb=new StringBuilder("मेरी saved memory: ");for(int i=Math.max(0,list.size()-5);i<list.size();i++)sb.append(list.get(i)).append(". ");respond(sb.toString());}
    void updateMemoryCount(){int n=0;for(String k:prefs.getAll().keySet())if(k.startsWith("mem_"))n++;memoryText.setText("Memory: "+n);}
    void addReminder(String q){java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d+)\\s*(minute|minutes|min|मिनट)",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(q);if(!m.find()){respond("उदाहरण: 10 मिनट बाद मुझे call करने की याद दिलाना।");return;}int minutes=Integer.parseInt(m.group(1));String task=q.substring(m.end()).trim();if(task.startsWith("बाद"))task=task.substring(2).trim();final String finalTask=task.isEmpty()?"Reminder":task;handler.postDelayed(()->respond("Reminder: "+finalTask),minutes*60_000L);respond(minutes+" मिनट बाद reminder लगा दिया।");}

    void askAI(String prompt){String key=prefs.getString("openai_key","").trim();if(key.isEmpty()){respond("AI Brain के लिए API key सेट करें, या supported command बोलें।");return;}String model=prefs.getString("openai_model","gpt-5.6-luna");respond("सोच रहा हूँ…");executor.submit(()->{try{URL url=new URL("https://api.openai.com/v1/responses");HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setRequestMethod("POST");c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);String body="{\"model\":\""+json(model)+"\",\"input\":[{\"role\":\"system\",\"content\":\"You are Tanvia Fusion, a concise helpful Hindi/Hinglish assistant.\"},{\"role\":\"user\",\"content\":\""+json(prompt)+"\"}]}";try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();String out=readAll(is);String text=extractOutputText(out);handler.post(()->respond(text.isEmpty()?"AI response नहीं मिला।":text));}catch(Exception e){handler.post(()->respond("AI connection में समस्या आई।"));}});}
    String json(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");}
    String readAll(InputStream is)throws Exception{if(is==null)return "";BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);return sb.toString();}
    String extractOutputText(String j){int p=j.indexOf("\"output_text\"");if(p>=0){int c=j.indexOf(':',p),q1=j.indexOf('"',c+1);if(q1>=0){StringBuilder s=new StringBuilder();boolean esc=false;for(int i=q1+1;i<j.length();i++){char ch=j.charAt(i);if(esc){s.append(ch);esc=false;}else if(ch=='\\')esc=true;else if(ch=='"')break;else s.append(ch);}return s.toString();}}return "";}
    void aiSettings(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,24,24,24);EditText key=new EditText(this);key.setHint("OpenAI API key");key.setInputType(0x81);key.setText(prefs.getString("openai_key",""));box.addView(key);EditText model=new EditText(this);model.setHint("Model");model.setText(prefs.getString("openai_model","gpt-5.6-luna"));box.addView(model);new AlertDialog.Builder(this).setTitle("AI Brain Settings").setView(box).setMessage("API key केवल इस app की local preferences में रखी जाएगी।").setPositiveButton("Save",(d,w)->{prefs.edit().putString("openai_key",key.getText().toString().trim()).putString("openai_model",model.getText().toString().trim()).apply();respond("AI settings save हो गईं।");}).setNegativeButton("Cancel",null).show();}
    void openPermissions(){try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}
    void respond(String s){reply.setText(s);if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"tanvia");}
    @Override protected void onDestroy(){if(sr!=null)sr.destroy();if(tts!=null){tts.stop();tts.shutdown();}executor.shutdownNow();super.onDestroy();}
}
