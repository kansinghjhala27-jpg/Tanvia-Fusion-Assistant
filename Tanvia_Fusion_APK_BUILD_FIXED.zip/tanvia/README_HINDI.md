# Tanvia Fusion - Background Voice Edition

यह Android Studio project है जिसमें background voice assistant जोड़ा गया है।

## मुख्य बदलाव
- Foreground microphone service
- Wake word: `Hey Tanvia`, `Tanvia`, `हे तनविया`
- Wake word के बाद Hindi/Hinglish command
- App खोले बिना supported apps/actions launch करना
- Continuous short speech-recognition sessions
- Required Android microphone foreground-service notification

## इस्तेमाल
1. Android Studio में project खोलें।
2. Vivo Y39 पर USB debugging/Developer options enable करें।
3. App install करें और Microphone permission दें।
4. App को एक बार खोलकर **Start Background Assistant** दबाएँ।
5. अब app बार-बार खोलने की जरूरत नहीं है। बोलें: `Hey Tanvia, YouTube खोलो`।
6. यदि Vivo background में service रोकता है, तो Tanvia Fusion के लिए battery optimization/background restrictions को Allow/Unrestricted करें।

## उदाहरण
- Hey Tanvia, YouTube खोलो
- Hey Tanvia, WhatsApp खोलो
- Hey Tanvia, Chrome खोलो
- Hey Tanvia, Google पर राजस्थान खोजो
- Hey Tanvia, Camera खोलो
- Hey Tanvia, Settings खोलो
- Hey Tanvia, Wi-Fi settings खोलो
- Hey Tanvia, Bluetooth settings खोलो
- Hey Tanvia, आवाज कम करो
- Hey Tanvia, आवाज बढ़ाओ
- Hey Tanvia, Calendar खोलो
- Hey Tanvia, Alarm खोलो
- Hey Tanvia, Messages खोलो
- Hey Tanvia, Phone खोलो

## Android limitation
Android background microphone access को security/privacy के कारण नियंत्रित करता है। यह project foreground microphone service और visible notification का उपयोग करता है। पहली बार service शुरू करना user action से होना चाहिए; कुछ phone/OEM battery policies service को रोक सकती हैं।

## Build
Android Studio > Open project > Build > Build APK(s).
