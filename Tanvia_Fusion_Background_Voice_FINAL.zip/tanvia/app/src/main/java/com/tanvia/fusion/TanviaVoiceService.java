package com.tanvia.fusion;

import android.app.*;
import android.content.*;
import android.media.AudioManager;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.net.Uri;
import java.util.*;

/**
 * Foreground voice assistant. It listens in short recognition sessions and only
 * executes commands after the wake word "Tanvia" / "Hey Tanvia" is detected.
 * Android still shows the required microphone foreground-service notification.
 */
public class TanviaVoiceService extends Service {
    private static final int NOTIFICATION_ID = 777;
    private static final String CHANNEL = "tanvia_voice";
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private boolean waitingForCommand = false;
    private boolean listening = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Tanvia Fusion active")
                .setContentText("Voice assistant is listening for the wake word: Tanvia")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, 128);
        else startForeground(NOTIFICATION_ID, n);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN"));
        });
        running = true;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel nc = new NotificationChannel(CHANNEL, "Tanvia Voice", NotificationManager.IMPORTANCE_LOW);
            nc.setDescription("Tanvia background voice assistant");
            getSystemService(NotificationManager.class).createNotificationChannel(nc);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) running = true;
        main.postDelayed(this::listenAgain, 250);
        return START_STICKY;
    }

    private void listenAgain() {
        if (!running || listening) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फोन पर voice recognition उपलब्ध नहीं है।");
            return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { listening = true; }
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { listening = false; }
                public void onPartialResults(Bundle b) {}
                public void onEvent(int a, Bundle b) {}
                public void onError(int e) { listening = false; main.postDelayed(TanviaVoiceService.this::listenAgain, 500); }
                public void onResults(Bundle b) {
                    listening = false;
                    ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (results != null && !results.isEmpty()) handleSpeech(results.get(0));
                    main.postDelayed(TanviaVoiceService.this::listenAgain, 350);
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            recognizer.startListening(i);
        } catch (Exception e) {
            listening = false;
            main.postDelayed(this::listenAgain, 1200);
        }
    }

    private void handleSpeech(String text) {
        if (text == null) return;
        String original = text.trim();
        String l = original.toLowerCase(Locale.ROOT);
        String wake = findWakeWord(l);

        if (waitingForCommand) {
            waitingForCommand = false;
            executeCommand(original);
            return;
        }

        if (wake != null) {
            String command = l.substring(wake.length()).trim();
            if (command.startsWith(",") || command.startsWith(":")) command = command.substring(1).trim();
            if (command.isEmpty()) {
                waitingForCommand = true;
                speak("जी, बोलिए।");
            } else {
                executeCommand(command);
            }
        }
    }

    private String findWakeWord(String l) {
        String[] wakes = {"hey tanvia", "hey tanvi", "tanvia", "tanvi", "हे तनविया", "हे तन्विया", "तनविया", "तन्विया"};
        for (String w : wakes) {
            if (l.startsWith(w)) return w;
        }
        return null;
    }

    private void executeCommand(String q) {
        String l = q.toLowerCase(Locale.ROOT).trim();
        try {
            if (l.contains("stop listening") || l.contains("voice बंद") || l.contains("बंद हो जाओ") || l.equals("stop")) {
                speak("ठीक है, voice assistant बंद कर रहा हूँ।");
                stopSelf();
            } else if (l.contains("youtube")) openPackage("com.google.android.youtube", "YouTube");
            else if (l.contains("whatsapp")) openPackage("com.whatsapp", "WhatsApp");
            else if (l.contains("instagram")) openPackage("com.instagram.android", "Instagram");
            else if (l.contains("spotify")) openPackage("com.spotify.music", "Spotify");
            else if (l.contains("chrome")) openPackage("com.android.chrome", "Chrome");
            else if (l.contains("gmail") || l.contains("email") || l.contains("मेल")) openUrl("https://mail.google.com/", "Gmail");
            else if (l.contains("google maps") || l.contains("maps") || l.contains("नक्शा")) openUrl("https://maps.google.com/", "Maps");
            else if (l.contains("chatgpt")) openUrl("https://chatgpt.com/", "ChatGPT");
            else if (l.contains("camera") || l.contains("कैमरा")) { speak("Camera खोल रहा हूँ।"); startActivity(new Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            else if (l.contains("settings") || l.contains("सेटिंग")) { startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Settings खोल रहा हूँ।"); }
            else if (l.contains("wifi") || l.contains("वाईफाई") || l.contains("wi-fi")) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Wi-Fi settings खोल रहा हूँ।"); }
            else if (l.contains("bluetooth")) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Bluetooth settings खोल रहा हूँ।"); }
            else if (l.contains("calendar") || l.contains("कैलेंडर")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Calendar खोल रहा हूँ।"); }
            else if (l.contains("alarm") || l.contains("अलार्म")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Alarm खोल रहा हूँ।"); }
            else if (l.contains("message") || l.contains("sms") || l.contains("मैसेज")) { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Messages खोल रहा हूँ।"); }
            else if (l.contains("call") || l.contains("कॉल")) { startActivity(new Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); speak("Phone खोल रहा हूँ।"); }
            else if (l.contains("volume up") || l.contains("आवाज बढ़ाओ") || l.contains("आवाज़ बढ़ाओ")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); speak("Volume बढ़ा दिया।"); }
            else if (l.contains("volume down") || l.contains("आवाज कम") || l.contains("आवाज़ कम")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); speak("Volume कम कर दिया।"); }
            else if (l.contains("mute") || l.contains("म्यूट")) { ((AudioManager)getSystemService(AUDIO_SERVICE)).adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); speak("Mute कर दिया।"); }
            else if (l.contains("google") || l.contains("search") || l.contains("सर्च") || l.contains("इंटरनेट")) {
                String search = l.replace("google", "").replace("search", "").replace("सर्च", "").replace("इंटरनेट", "").trim();
                openUrl("https://www.google.com/search?q=" + Uri.encode(search.isEmpty() ? q : search), "Google search");
            } else {
                speak("यह command अभी मेरी quick actions में नहीं है।");
            }
        } catch (Exception e) {
            speak("यह action इस फोन पर उपलब्ध नहीं है या permission चाहिए।");
        }
    }

    private void openPackage(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            speak(name + " खोल रहा हूँ।");
        } else {
            openUrl("https://www.google.com/search?q=" + Uri.encode(name), name);
        }
    }

    private void openUrl(String url, String name) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        speak(name + " खोल रहा हूँ।");
    }

    private void speak(String s) {
        if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "tanvia");
    }

    @Override public void onDestroy() {
        running = false;
        listening = false;
        if (recognizer != null) { try { recognizer.cancel(); } catch (Exception ignored) {} recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
