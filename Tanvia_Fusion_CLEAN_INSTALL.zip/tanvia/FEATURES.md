# Fusion feature matrix

| Source | Merged into Fusion |
|---|---|
| JARVIS Windows | voice, AI brain, memory, reminders, app/web opening, search, camera concept, volume, system info, lock concept |
| Tanvia PWA | Hindi UI concept, voice/TTS, memory, WhatsApp/YouTube/Google/Camera/Call/SMS/Music/Battery/Date/Calendar/Settings |
| Tanvia Android | native Android voice, TTS, permissions, accessibility foundation, Wi-Fi/Bluetooth settings, battery/system commands |
| Fusion additions | one unified command router, local AI settings, combined documentation, reference_projects folder |


## Final additions
- Futuristic unified Android shell
- Microphone foreground-service foundation for user-enabled background voice
- Android 14/15 foreground-service declaration compatibility
- Unified command router and local memory
- Original ZIP references retained for further porting
