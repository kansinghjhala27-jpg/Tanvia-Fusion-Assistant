package com.tanvia.fusion;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class TanviaAccessibilityService extends AccessibilityService {
    private static TanviaAccessibilityService instance;

    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}

    public static TanviaAccessibilityService get() { return instance; }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root != null && clickRecursive(root, text);
    }

    private boolean clickRecursive(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        CharSequence t = node.getText();
        if (t != null && t.toString().equalsIgnoreCase(text) && node.isClickable()) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (clickRecursive(node.getChild(i), text)) return true;
        }
        return false;
    }
}
